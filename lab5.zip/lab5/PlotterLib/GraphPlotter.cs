﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace PlotterLib

{
    // Делегат для представления функции
    public delegate double FunctionDelegate(double x);

    // Класс для построения графика функции
    public class GraphPlotter : Form
    {
        private PictureBox pictureBox;
        private FunctionDelegate function;

        public GraphPlotter()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "Graph Plotter";
            this.Size = new Size(800, 600);

            pictureBox = new PictureBox();
            pictureBox.Dock = DockStyle.Fill;
            pictureBox.BackColor = Color.White;

            this.Controls.Add(pictureBox);
        }

        public void SetFunction(FunctionDelegate func)
        {
            function = func;
            RefreshGraph();
        }

        private void PictureBox_Paint(object sender, PaintEventArgs e)
        {
            if (function == null)
                return;

            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Blue);

            double scaleX = pictureBox.Width / 10.0; // Adjust scale as needed
            double scaleY = pictureBox.Height / 10.0; // Adjust scale as needed

            double prevX = 0;
            double prevY = function(prevX);

            for (int i = 1; i < pictureBox.Width; i++)
            {
                double x = i / scaleX;
                double y = function(x);

                g.DrawLine(pen, (float)(prevX * scaleX), pictureBox.Height - (float)(prevY * scaleY),
                                   (float)(x * scaleX), pictureBox.Height - (float)(y * scaleY));

                prevX = x;
                prevY = y;
            }

            pen.Dispose();
        }

        private void RefreshGraph()
        {
            pictureBox.Refresh();
        }
    }
}
