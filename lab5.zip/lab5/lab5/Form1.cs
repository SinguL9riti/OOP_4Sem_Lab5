﻿using System;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form1 : Form
    {
        private GraphPlotter graphPlotter;

        public Form1()
        {
            InitializeComponent();

            // Создаем экземпляр GraphPlotter и настраиваем его
            graphPlotter = new GraphPlotter();
            graphPlotter.Dock = DockStyle.Fill;
            this.Controls.Add(graphPlotter);

            // Создаем кнопку для выбора функции
            Button selectFunctionButton = new Button();
            selectFunctionButton.Text = "Выбрать функцию";
            selectFunctionButton.Click += SelectFunctionButton_Click;
            this.Controls.Add(selectFunctionButton);

            // Устанавливаем начальную функцию - косинус
            graphPlotter.SetFunction(Math.Cos);
        }

        private void SelectFunctionButton_Click(object sender, EventArgs e)
        {
            // Создаем и отображаем форму выбора функции
            FunctionSelectionForm selectionForm = new FunctionSelectionForm();
            selectionForm.FunctionSelected += SetSelectedFunction; // Изменено на SetSelectedFunction
            selectionForm.ShowDialog();
        }

        // Изменяем метод SetSelectedFunction в классе Form1
        public void SetSelectedFunction(object sender, FunctionSelectedEventArgs e)
        {
            // Устанавливаем выбранную функцию в GraphPlotter
            switch (e.SelectedFunctionIndex)
            {
                case 0:
                    graphPlotter.SetFunction(Math.Sin);
                    break;
                case 1:
                    graphPlotter.SetFunction(Math.Cos);
                    break;
                case 2:
                    graphPlotter.SetFunction(Math.Tan);
                    break;
                case 3:
                    graphPlotter.SetFunction(Math.Sinh);
                    break;
                case 4:
                    graphPlotter.SetFunction(Math.Cosh);
                    break;
                default:
                    // Если выбран неверный индекс, просто игнорируем
                    break;
            }
        }

    }
}
