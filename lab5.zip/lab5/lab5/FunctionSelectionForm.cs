﻿using System;
using System.Windows.Forms;

namespace lab5
{
    public partial class FunctionSelectionForm : Form
    {
        // ComboBox для выбора функции
        private ComboBox functionComboBox;

        // Кнопка подтверждения выбора функции
        private Button okButton;

        // Событие, которое будет вызываться при выборе функции
        public event EventHandler<FunctionSelectedEventArgs> FunctionSelected;

        public FunctionSelectionForm()
        {
            InitializeComponent(); // Вызываем метод инициализации компонентов

            // Создаем и настраиваем ComboBox для выбора функции
            functionComboBox = new ComboBox();
            functionComboBox.Dock = DockStyle.Top;
            functionComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            functionComboBox.Items.Add("Синус");
            functionComboBox.Items.Add("Косинус");
            functionComboBox.Items.Add("Тангенс");
            functionComboBox.Items.Add("Синус гиперболический");
            functionComboBox.Items.Add("Косинус гиперболический");
            functionComboBox.SelectedIndex = 0;

            // Создаем и настраиваем кнопку подтверждения выбора функции
            okButton = new Button();
            okButton.Text = "Выбрать";
            okButton.Dock = DockStyle.Top;
            okButton.Click += okButton_Click;

            // Добавляем элементы управления на форму
            Controls.Add(okButton);
            Controls.Add(functionComboBox);
        }

        private void InitializeComponent()
        {
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            // Получаем индекс выбранной функции
            int selectedIndex = functionComboBox.SelectedIndex;

            // Создаем аргументы с выбранной функцией
            FunctionSelectedEventArgs args = new FunctionSelectedEventArgs(selectedIndex);

            // Вызываем событие FunctionSelected
            FunctionSelected?.Invoke(this, args);

            // Закрываем окно
            Close();
        }
    }

    // Класс для передачи аргументов выбранной функции
    public class FunctionSelectedEventArgs : EventArgs
    {
        public int SelectedFunctionIndex { get; }

        public FunctionSelectedEventArgs(int selectedIndex)
        {
            SelectedFunctionIndex = selectedIndex;
        }
    }
}
