﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace lab5
{

    public delegate void FunctionSetEventHandler(FunctionDelegate function);

    public delegate double FunctionDelegate(double x);

    public class GraphPlotter : UserControl
    {
        private FunctionDelegate function;

        // Событие установки функции
        public event FunctionSetEventHandler FunctionSet;

        public GraphPlotter()
        {
            this.Paint += GraphPlotter_Paint;
        }

        public void SetFunction(FunctionDelegate func)
        {
            function = func;
            Refresh();

            // Вызываем событие при установке функции
            OnFunctionSet(func);
        }

        // Метод для вызова события установки функции
        protected virtual void OnFunctionSet(FunctionDelegate function)
        {
            FunctionSet?.Invoke(function);
        }

        private void GraphPlotter_Paint(object sender, PaintEventArgs e)
        {
            if (function == null)
                return;

            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Blue);

            double scaleX = this.Width / 10.0;
            double scaleY = this.Height / 10.0;

            double xAxis = this.Height / 2.0; // Ось X будет в центре экрана

            g.DrawLine(Pens.Black, 0, (int)xAxis, this.Width, (int)xAxis); // Ось X

            double prevX = 0;
            double prevY = function(prevX);

            for (int i = 1; i < this.Width; i++)
            {
                double x = i / scaleX;
                double y = function(x);

                g.DrawLine(pen, (float)(prevX * scaleX), (float)(xAxis - prevY * scaleY),
                                   (float)(x * scaleX), (float)(xAxis - y * scaleY));

                prevX = x;
                prevY = y;
            }

            pen.Dispose();
        }
    }
}
