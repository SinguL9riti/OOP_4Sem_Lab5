﻿using System;
using System.Windows.Forms;

namespace lab5
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Создаем и отображаем форму выбора функции
            FunctionSelectionForm selectionForm = new FunctionSelectionForm();
            selectionForm.FunctionSelected += (sender, e) =>
            {
                // Создаем форму для отображения графика
                Form1 mainForm = new Form1();

                // Устанавливаем выбранную функцию в форму для отображения графика
                mainForm.SetSelectedFunction(sender, e);

                // Отображаем форму как модальное диалоговое окно
                mainForm.ShowDialog();
            };
            Application.Run(selectionForm);
        }
    }
}
